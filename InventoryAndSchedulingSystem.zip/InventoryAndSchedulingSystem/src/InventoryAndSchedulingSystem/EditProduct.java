package InventoryAndSchedulingSystem;


import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class EditProduct extends javax.swing.JFrame {

    public EditProduct() 
    {
        initComponents();
        
        productName_TextField.setEditable(false);
        category_TextField.setEditable(false);
        
        try 
        {
            tableUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(EditProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();
        editProduct_Label = new javax.swing.JLabel();
        editProduct_ScrollPane = new javax.swing.JScrollPane();
        editProduct_Table = new javax.swing.JTable();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        productName_Label = new javax.swing.JLabel();
        productName_TextField = new javax.swing.JTextField();
        quantity_Label = new javax.swing.JLabel();
        category_Label = new javax.swing.JLabel();
        editProduct_Button = new javax.swing.JButton();
        category_TextField = new javax.swing.JTextField();
        deleteProduct_Button = new javax.swing.JButton();
        quantity_TextField = new javax.swing.JTextField();
        searchBar_TextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EDIT PRODUCT");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setPreferredSize(new java.awt.Dimension(850, 597));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        editProduct_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        editProduct_Label.setForeground(new java.awt.Color(255, 255, 255));
        editProduct_Label.setText("Edit Product");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(editProduct_Label)
                    .addComponent(back_Button))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 658, Short.MAX_VALUE)
                .addComponent(clientShop_Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clientShop_Logo, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                    .addGroup(top_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(editProduct_Label)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 950, 90));

        editProduct_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Product Name", "Price", "Quantity", "Category"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        editProduct_Table.getTableHeader().setReorderingAllowed(false);
        editProduct_Table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editProduct_TableMouseClicked(evt);
            }
        });
        editProduct_ScrollPane.setViewportView(editProduct_Table);
        if (editProduct_Table.getColumnModel().getColumnCount() > 0) {
            editProduct_Table.getColumnModel().getColumn(0).setResizable(false);
            editProduct_Table.getColumnModel().getColumn(1).setResizable(false);
            editProduct_Table.getColumnModel().getColumn(2).setResizable(false);
            editProduct_Table.getColumnModel().getColumn(3).setResizable(false);
        }

        whole_Panel.add(editProduct_ScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 104, 662, 400));

        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price_Label.setText("Price");
        whole_Panel.add(price_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 230, -1, -1));

        price_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                price_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                price_TextFieldFocusLost(evt);
            }
        });
        price_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                price_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(price_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 250, 30));

        productName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        productName_Label.setText("Product Name");
        whole_Panel.add(productName_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 160, -1, -1));
        whole_Panel.add(productName_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 190, 250, 30));

        quantity_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        quantity_Label.setText("Quantity");
        whole_Panel.add(quantity_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, -1, -1));

        category_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        category_Label.setText("Category");
        whole_Panel.add(category_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, -1, -1));

        editProduct_Button.setBackground(new java.awt.Color(204, 204, 204));
        editProduct_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        editProduct_Button.setText("Update");
        editProduct_Button.setToolTipText("Update Product");
        editProduct_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        editProduct_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editProduct_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(editProduct_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(282, 516, 100, 34));
        whole_Panel.add(category_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 250, 30));

        deleteProduct_Button.setBackground(new java.awt.Color(204, 204, 204));
        deleteProduct_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        deleteProduct_Button.setText("Delete");
        deleteProduct_Button.setToolTipText("Delete Product");
        deleteProduct_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        deleteProduct_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteProduct_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(deleteProduct_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(388, 516, 100, 34));

        quantity_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                quantity_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(quantity_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 330, 250, 30));

        searchBar_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        searchBar_TextField.setForeground(new java.awt.Color(153, 153, 153));
        searchBar_TextField.setText("Search");
        searchBar_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusLost(evt);
            }
        });
        searchBar_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchBar_TextFieldActionPerformed(evt);
            }
        });
        searchBar_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchBar_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(searchBar_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 250, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, 950, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 570, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    static int selectedRowIndex;
    
    private void tableUpdate() throws SQLException{
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM inventory_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)editProduct_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Product_Name"));
                    vec.add(rs.getString("Product_Price"));
                    vec.add(rs.getString("Product_Quantity"));
                    vec.add(rs.getString("Product_Category"));
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void clearFields() 
    {
        productName_TextField.setText("");
        price_TextField.setText("");
        quantity_TextField.setText("");
        category_TextField.setText("");
    }
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        InventoryMenu InventoryMenuModule = new InventoryMenu();
        InventoryMenuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void editProduct_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editProduct_ButtonActionPerformed

        String Product_Name = productName_TextField.getText();
        String Product_Price = price_TextField.getText();
        String Product_Quantity = quantity_TextField.getText();
        String Product_Category = category_TextField.getText(); 

        DefaultTableModel dtm = (DefaultTableModel) editProduct_Table.getModel();
        int selectedIndex = editProduct_Table.getSelectedRow();
        
        DecimalFormat decFormat=new DecimalFormat("0.00");
        
        
        
        

        
        if (selectedIndex != -1) 
        {
            if(productName_TextField.getText().equals(editProduct_Table.getValueAt(selectedIndex, 0))&& price_TextField.getText().equals(editProduct_Table.getValueAt(selectedIndex, 1)) && quantity_TextField.getText().equals(editProduct_Table.getValueAt(selectedIndex, 2)) && category_TextField.getText().equals(editProduct_Table.getValueAt(selectedIndex, 3))) {
                JOptionPane.showMessageDialog(this, "No update done");
                clearFields();
            }
            
            else if (productName_TextField.getText().equals("")|| price_TextField.getText().equals("") || quantity_TextField.getText().equals("") ||category_TextField.getText().equals("")) 
            {
                JOptionPane.showMessageDialog(this, "Empty Fields", "Update", JOptionPane.INFORMATION_MESSAGE);
                clearFields();
            } 
            else if (quantity_TextField.getText().equals("0")) 
            {
                JOptionPane.showMessageDialog(this, "Invalid Quantity 0", "Update", JOptionPane.INFORMATION_MESSAGE);
                clearFields() ;
            }
            else if (price_TextField.getText().equals("0.00"))
            {
                JOptionPane.showMessageDialog(this, "Invalid Price", "Update", JOptionPane.INFORMATION_MESSAGE);
                clearFields() ;
                
            }
            else 
            {
                int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to update?", "Update", JOptionPane.YES_NO_OPTION);
                    if (choice == JOptionPane.YES_OPTION) 
                    {
                        double product_Amount = Double.parseDouble(Product_Price);
                        DecimalFormat formatter = new DecimalFormat("#,###.00");
        
                        String fproduct_Amount= (formatter.format(product_Amount));
                        try
                        {
                            Class.forName(dbDriver);
                            con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
                            PreparedStatement updateStmt = con.prepareStatement("UPDATE inventory_database SET Product_Price=?, Product_Quantity=?, Product_Category=? WHERE Product_Name=?");
                            updateStmt.setString(1, fproduct_Amount);
                            updateStmt.setString(2, Product_Quantity);
                            updateStmt.setString(3, Product_Category);
                            updateStmt.setString(4, Product_Name);
                            
                            int rowsUpdated = updateStmt.executeUpdate();
                            
                            if (rowsUpdated > 0) 
                            {
                                JOptionPane.showMessageDialog(this, "Record Updated Successfully", "Update", JOptionPane.INFORMATION_MESSAGE);
                                tableUpdate(); 
                                
                                productName_TextField.setText("");
                                price_TextField.setText("");
                                quantity_TextField.setText("");
                                category_TextField.setText("");
                            } 
                            else 
                            {
                                JOptionPane.showMessageDialog(this, "Failed to Update Record", "Error", JOptionPane.ERROR_MESSAGE);
                            }

                            }
                            catch(Exception e)
                            {
                                Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, e);
                                JOptionPane.showMessageDialog(this, "Database Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                            }
                    }
                    else if (choice == JOptionPane.NO_OPTION){
                         JOptionPane.showMessageDialog(this, "Update Cancelled", "Cancelled", JOptionPane.INFORMATION_MESSAGE);
                    }
            }
        }
        else {
            JOptionPane.showMessageDialog(this, "Please select a row to update.", "Selection Required", JOptionPane.INFORMATION_MESSAGE);
        }

    }//GEN-LAST:event_editProduct_ButtonActionPerformed

    private void editProduct_TableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editProduct_TableMouseClicked
        DefaultTableModel dtm = (DefaultTableModel)editProduct_Table.getModel();
        int selectedIndex = editProduct_Table.getSelectedRow();

        selectedRowIndex = editProduct_Table.getSelectedRow();
    
        productName_TextField.setText(dtm.getValueAt(selectedIndex, 0).toString());
        price_TextField.setText(dtm.getValueAt(selectedIndex, 1).toString());
        quantity_TextField.setText(dtm.getValueAt(selectedIndex, 2).toString());
        category_TextField.setText(dtm.getValueAt(selectedIndex, 3).toString());
    }//GEN-LAST:event_editProduct_TableMouseClicked

    private void deleteProduct_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteProduct_ButtonActionPerformed
        String Product_Name = productName_TextField.getText();
        String Product_Price = price_TextField.getText();
        String Product_Quantity = quantity_TextField.getText();
        String Product_Category = category_TextField.getText(); 
        
        DefaultTableModel dtm = (DefaultTableModel)editProduct_Table.getModel();
        int selectedIndex = editProduct_Table.getSelectedRow();
        
        if (selectedIndex != -1) 
        {
            int choice = JOptionPane.showConfirmDialog(this,"Do you sure want to delete", "Delete",JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION )
        
          try
          {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);  
            insert = con.prepareStatement("DELETE FROM inventory_database WHERE Product_Name =? ");
            insert.setString(1, Product_Name);
            insert.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Record Deleted ","Delete",JOptionPane.INFORMATION_MESSAGE);
            tableUpdate();
            
            productName_TextField.setText("");
            price_TextField.setText("");
            quantity_TextField.setText("");
            category_TextField.setText("");
         }
        catch(Exception e)
        {
                    
        }
          
        else
        {
         JOptionPane.showMessageDialog(null, "Failed to delete profile.","Error",JOptionPane.ERROR_MESSAGE);   
             productName_TextField.setText("");
            price_TextField.setText("");
            quantity_TextField.setText("");
            category_TextField.setText("");
        }
        }
        else
        {
          JOptionPane.showMessageDialog(this, "Please select a row to update.", "Selection Required", JOptionPane.INFORMATION_MESSAGE);  
        }
              
          
    }//GEN-LAST:event_deleteProduct_ButtonActionPerformed

    private void quantity_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_quantity_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            quantity_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            quantity_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_quantity_TextFieldKeyTyped

    private void price_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_price_TextFieldKeyTyped
       char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            price_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            price_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_price_TextFieldKeyTyped

    private void price_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_price_TextFieldFocusGained
        if (price_TextField.getText().equals(""))
        {
            price_TextField.setText("");
            price_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_price_TextFieldFocusGained

    private void price_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_price_TextFieldFocusLost
        if (price_TextField.getText().equals(""))
        {
            price_TextField.setText("");   
        }
    }//GEN-LAST:event_price_TextFieldFocusLost

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );
    }//GEN-LAST:event_formWindowClosing

    private void searchBar_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchBar_TextFieldActionPerformed
        DefaultTableModel dtm = (DefaultTableModel) editProduct_Table.getModel();

        TableRowSorter<DefaultTableModel> searchBar = new TableRowSorter<>(dtm);
        editProduct_Table.setRowSorter(searchBar);

        String searchText = searchBar_TextField.getText();
        searchBar.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
    }//GEN-LAST:event_searchBar_TextFieldActionPerformed

    private void searchBar_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchBar_TextFieldKeyTyped
        DefaultTableModel dtm = (DefaultTableModel) editProduct_Table.getModel();

        TableRowSorter<DefaultTableModel> searchBar = new TableRowSorter<>(dtm);
        editProduct_Table.setRowSorter(searchBar);

        String searchText = searchBar_TextField.getText();
        searchBar.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
    }//GEN-LAST:event_searchBar_TextFieldKeyTyped

    private void searchBar_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusGained
        if ( searchBar_TextField.getText().equals("Search"))
        {
             searchBar_TextField.setText("");
             searchBar_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusGained

    private void searchBar_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusLost
        if (searchBar_TextField.getText().equals(""))
        {
            searchBar_TextField.setText("Search");
            searchBar_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusLost

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try {
            tableUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(EditProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
{
        
    }
    }//GEN-LAST:event_formWindowOpened

    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditProduct().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel category_Label;
    private javax.swing.JTextField category_TextField;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JButton deleteProduct_Button;
    private javax.swing.JButton editProduct_Button;
    private javax.swing.JLabel editProduct_Label;
    private javax.swing.JScrollPane editProduct_ScrollPane;
    private javax.swing.JTable editProduct_Table;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JLabel productName_Label;
    private javax.swing.JTextField productName_TextField;
    private javax.swing.JLabel quantity_Label;
    private javax.swing.JTextField quantity_TextField;
    private javax.swing.JTextField searchBar_TextField;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
