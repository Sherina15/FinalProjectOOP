package InventoryAndSchedulingSystem;

import static InventoryAndSchedulingSystem.ViewAdminAccount.viewAdminAccountList_Table;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

public class EditAccount extends javax.swing.JFrame {


    public EditAccount() 
    {
        initComponents();
        
        name_TextField.setEditable(false);
        email_TextField.setEditable(false);
        phoneNumber_TextField.setEditable(false);
        username_TextField.setEditable(false);
        
        try 
        {
            tableUpdate();  
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(EditAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = ""; 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        top_Panel = new javax.swing.JPanel();
        editAccount_Label = new javax.swing.JLabel();
        back_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();
        editAccount_ScrollPane = new javax.swing.JScrollPane();
        editAccount_Table = new javax.swing.JTable();
        email_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        password_Label = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        showPassword_CheckBox = new javax.swing.JCheckBox();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        save_Button = new javax.swing.JButton();
        username_TextField = new javax.swing.JTextField();
        name_TextField = new javax.swing.JTextField();
        name_Label = new javax.swing.JLabel();
        email_Label = new javax.swing.JLabel();
        searchBar_TextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("EDIT ACCOUNT");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        editAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        editAccount_Label.setForeground(new java.awt.Color(255, 255, 255));
        editAccount_Label.setText("EDIT ACCOUNT");

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(editAccount_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 480, Short.MAX_VALUE)
                .addComponent(clientShop_Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addComponent(back_Button)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(editAccount_Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(clientShop_Logo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 920, 100));

        editAccount_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Name", "Email", "Phone Number", "Username", "Password"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        editAccount_Table.getTableHeader().setReorderingAllowed(false);
        editAccount_Table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                editAccount_TableMouseClicked(evt);
            }
        });
        editAccount_ScrollPane.setViewportView(editAccount_Table);
        if (editAccount_Table.getColumnModel().getColumnCount() > 0) {
            editAccount_Table.getColumnModel().getColumn(0).setResizable(false);
            editAccount_Table.getColumnModel().getColumn(1).setResizable(false);
            editAccount_Table.getColumnModel().getColumn(2).setResizable(false);
            editAccount_Table.getColumnModel().getColumn(3).setResizable(false);
            editAccount_Table.getColumnModel().getColumn(4).setResizable(false);
        }

        whole_Panel.add(editAccount_ScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 680, 430));
        whole_Panel.add(email_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 250, 200, 35));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setText("Username");
        whole_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 360, -1, -1));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setText("Password");
        whole_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 430, -1, -1));
        whole_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 460, 200, 35));

        showPassword_CheckBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        showPassword_CheckBox.setText("Show Password");
        showPassword_CheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showPassword_CheckBoxActionPerformed(evt);
            }
        });
        whole_Panel.add(showPassword_CheckBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 500, -1, -1));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        whole_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 290, -1, -1));

        phoneNumber_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                phoneNumber_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 320, 200, 35));

        save_Button.setBackground(new java.awt.Color(204, 204, 204));
        save_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        save_Button.setText("Save");
        save_Button.setToolTipText("Update Account");
        save_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        save_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                save_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(save_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 550, 90, 30));
        whole_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 390, 200, 35));
        whole_Panel.add(name_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 180, 200, 35));

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name_Label.setText("Name");
        whole_Panel.add(name_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 150, -1, -1));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        email_Label.setText("Email");
        whole_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 220, -1, -1));

        searchBar_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        searchBar_TextField.setForeground(new java.awt.Color(153, 153, 153));
        searchBar_TextField.setText("Search");
        searchBar_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusLost(evt);
            }
        });
        searchBar_TextField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchBar_TextFieldMouseClicked(evt);
            }
        });
        searchBar_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchBar_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(searchBar_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 110, 200, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 921, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 596, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
   
    static int selectedRowIndex;
    
    private void tableUpdate() throws SQLException{
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM registration_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)editAccount_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Name"));
                    vec.add(rs.getString("Email"));
                    vec.add(rs.getString("PhoneNumber"));
                    vec.add(rs.getString("Username"));
                    vec.add(rs.getString("Password"));     
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(EditAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void updateAccount() 
    {
        ViewAdminAccount  viewAdminAccountModule = new ViewAdminAccount();
        
        DefaultTableModel dtm = (DefaultTableModel) editAccount_Table.getModel();
        int selectedIndex = editAccount_Table.getSelectedRow();
        
        String acc_Name = name_TextField.getText();
        String acc_Email = email_TextField.getText();
        String acc_Username = username_TextField.getText();
        String acc_Password = String.valueOf(password_Field.getPassword());
        String acc_Phone_Number = phoneNumber_TextField.getText();

        String regEx_PhoneNumber = "^09\\d{9}$";

        Pattern pattern_PhoneNumber = Pattern.compile(regEx_PhoneNumber);

        Matcher matcher_PhoneNumber = pattern_PhoneNumber.matcher(acc_Phone_Number);

        String accUsername;
        int account = 0;
        
        for (int i = 0; i < ViewAdminAccount.viewAdminAccountList_Table.getRowCount(); i++)
        {
            accUsername = viewAdminAccountList_Table.getValueAt(i, 3).toString();
            
            if (acc_Username.equalsIgnoreCase(viewAdminAccountList_Table.getValueAt(i, 3).toString()))
            {
                account++;  
            }
        }
        
                if (selectedIndex != -1) 
                {

                    if (name_TextField.getText().equals("") || email_TextField.getText().equals("") ||  phoneNumber_TextField.getText().equals("") || username_TextField.getText().equals("") || password_Field.getText().equals(""))
                    {
                        JOptionPane.showMessageDialog(this, "Empty fields");
                        clearFields();
                    }
                    else
                    {
                       int choice = JOptionPane.showConfirmDialog(this, "Do you want to update?", "Update", JOptionPane.YES_NO_OPTION);

                        if (choice == JOptionPane.YES_OPTION)
                        {
                            try
                            {
                                Class.forName(dbDriver);
                                Connection con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
                                insert = con.prepareStatement("UPDATE registration_database SET Username=?, Password=?, PhoneNumber=? WHERE Email=?");
                                insert.setString(1, acc_Username);
                                insert.setString(2, acc_Password);
                                insert.setString(3, acc_Phone_Number);
                                insert.setString(4, acc_Email);

                                int rowsUpdated = insert.executeUpdate();

                                    if (rowsUpdated > 0) 
                                    {
                                        JOptionPane.showMessageDialog(this, "Record Updated Successfully", "Update", JOptionPane.INFORMATION_MESSAGE);
                                        tableUpdate();
                                        clearFields(); 

                                        viewAdminAccountModule.setVisible(true);
                                        dispose();
                                    }
                                    else
                                    {
                                        JOptionPane.showMessageDialog(this, "Failed to Update profile.", "Error", JOptionPane.ERROR_MESSAGE);
                                        clearFields();
                                    }
                            }
                            catch(Exception e)
                            {
                                Logger.getLogger(EditAccount.class.getName()).log(Level.SEVERE, null, e);
                                JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE); 
                                clearFields();
                            }

                        }
                        else if (choice == JOptionPane.NO_OPTION)
                        {
                           JOptionPane.showMessageDialog(this, "Update Cancelled.", "Cancelled", JOptionPane.INFORMATION_MESSAGE); 
                        }
                    }
                }
                else 
                {
                    JOptionPane.showMessageDialog(this, "Please select a row to update.", "Selection Required", JOptionPane.INFORMATION_MESSAGE);
                }
   }
 
    private void clearFields() 
    {
        name_TextField.setText("");
        email_TextField.setText("");
        username_TextField.setText("");
        password_Field.setText("");
        phoneNumber_TextField.setText("");
    }
    
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
        viewAdminAccountModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void save_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_save_ButtonActionPerformed
            
        updateAccount();
        
    }//GEN-LAST:event_save_ButtonActionPerformed

    private void showPassword_CheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showPassword_CheckBoxActionPerformed
        if (showPassword_CheckBox.isSelected())
        {
            password_Field.setEchoChar((char)0);
        }
        else 
        {
            password_Field.setEchoChar('•');
        }
    }//GEN-LAST:event_showPassword_CheckBoxActionPerformed

    private void editAccount_TableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_editAccount_TableMouseClicked
        DefaultTableModel dtm = (DefaultTableModel)editAccount_Table.getModel();
        int selectedIndex = editAccount_Table.getSelectedRow();

        selectedRowIndex = editAccount_Table.getSelectedRow();
   
        name_TextField.setText(dtm.getValueAt(selectedIndex, 0).toString());
        email_TextField.setText(dtm.getValueAt(selectedIndex, 1).toString());
        phoneNumber_TextField.setText(dtm.getValueAt(selectedIndex, 2).toString());
        username_TextField.setText(dtm.getValueAt(selectedIndex, 3).toString());
        password_Field.setText(dtm.getValueAt(selectedIndex,4).toString());
        
    }//GEN-LAST:event_editAccount_TableMouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        JOptionPane.showMessageDialog(null, "Exiting application...","Exit Application",JOptionPane.INFORMATION_MESSAGE );
    }//GEN-LAST:event_formWindowClosing

    private void phoneNumber_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            phoneNumber_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            phoneNumber_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_phoneNumber_TextFieldKeyTyped

    private void searchBar_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusGained
        if ( searchBar_TextField.getText().equals("Search"))
        {
             searchBar_TextField.setText("");
             searchBar_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusGained

    private void searchBar_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusLost
        if (searchBar_TextField.getText().equals(""))
        {
            searchBar_TextField.setText("Search");
            searchBar_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusLost

    private void searchBar_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchBar_TextFieldKeyTyped
        DefaultTableModel dtm = (DefaultTableModel) editAccount_Table.getModel();

        TableRowSorter<DefaultTableModel> searchBar = new TableRowSorter<>(dtm);
        editAccount_Table.setRowSorter(searchBar);

        String searchText = searchBar_TextField.getText();
        searchBar.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
    }//GEN-LAST:event_searchBar_TextFieldKeyTyped

    private void searchBar_TextFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchBar_TextFieldMouseClicked
        
        clearFields();
        
    }//GEN-LAST:event_searchBar_TextFieldMouseClicked


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EditAccount().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel editAccount_Label;
    private javax.swing.JScrollPane editAccount_ScrollPane;
    private javax.swing.JTable editAccount_Table;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField;
    private javax.swing.JLabel name_Label;
    private javax.swing.JTextField name_TextField;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JButton save_Button;
    private javax.swing.JTextField searchBar_TextField;
    private javax.swing.JCheckBox showPassword_CheckBox;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
