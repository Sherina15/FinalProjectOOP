package InventoryAndSchedulingSystem;

import static InventoryAndSchedulingSystem.ViewSchedule.viewSchedule_Table;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


public class ViewProduct extends javax.swing.JFrame {

    public ViewProduct() 
    {
        initComponents();
        try 
        {
            tableUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(ViewProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
            
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        whole_Panel = new javax.swing.JPanel();
        viewProduct_Label = new javax.swing.JLabel();
        lower_Panel = new javax.swing.JPanel();
        viewProduct_ScrollPane = new javax.swing.JScrollPane();
        viewProduct_Table = new javax.swing.JTable();
        back_Button = new javax.swing.JButton();
        searchBar_TextField = new javax.swing.JTextField();
        clientShop_Logo = new javax.swing.JLabel();

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Product Number");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("VIEW PRODUCT");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(0, 0, 0));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        viewProduct_Label.setBackground(new java.awt.Color(0, 0, 0));
        viewProduct_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        viewProduct_Label.setForeground(new java.awt.Color(255, 255, 255));
        viewProduct_Label.setText("VIEW PRODUCT");
        whole_Panel.add(viewProduct_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, -1, -1));

        lower_Panel.setBackground(new java.awt.Color(255, 255, 255));
        lower_Panel.setForeground(new java.awt.Color(255, 255, 255));

        viewProduct_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Product Name", "Price", "Quantity", "Categories"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        viewProduct_Table.getTableHeader().setReorderingAllowed(false);
        viewProduct_ScrollPane.setViewportView(viewProduct_Table);
        if (viewProduct_Table.getColumnModel().getColumnCount() > 0) {
            viewProduct_Table.getColumnModel().getColumn(0).setResizable(false);
            viewProduct_Table.getColumnModel().getColumn(1).setResizable(false);
            viewProduct_Table.getColumnModel().getColumn(2).setResizable(false);
            viewProduct_Table.getColumnModel().getColumn(3).setResizable(false);
        }

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Close");
        back_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        searchBar_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        searchBar_TextField.setForeground(new java.awt.Color(153, 153, 153));
        searchBar_TextField.setText("Search");
        searchBar_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusLost(evt);
            }
        });
        searchBar_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchBar_TextFieldKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout lower_PanelLayout = new javax.swing.GroupLayout(lower_Panel);
        lower_Panel.setLayout(lower_PanelLayout);
        lower_PanelLayout.setHorizontalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, lower_PanelLayout.createSequentialGroup()
                .addGap(0, 20, Short.MAX_VALUE)
                .addGroup(lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(viewProduct_ScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 837, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchBar_TextField, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23))
        );
        lower_PanelLayout.setVerticalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(searchBar_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(viewProduct_ScrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 395, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        whole_Panel.add(lower_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 100, -1, -1));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N
        whole_Panel.add(clientShop_Logo, new org.netbeans.lib.awtextra.AbsoluteConstraints(793, 17, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void tableUpdate() throws SQLException{
        
//        DecimalFormat decFormat=new DecimalFormat("0.00");
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM inventory_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)viewProduct_Table.getModel();
            dtm.setRowCount(0);
            
//            
//            String price;
//             for(int i = 0; i < viewProduct_Table.getRowCount(); i++)
//        {
//           price = (viewProduct_Table.getValueAt(i, 1).toString());
//           
//             double product_Amount = Double.parseDouble(price);
//              DecimalFormat formatter = new DecimalFormat("#,###.00");        
//              String fproduct_Amount= (formatter.format(product_Amount));
//              
//        }
//              
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Product_Name"));
                    vec.add(rs.getString("Product_Price"));
                    vec.add(rs.getString("Product_Quantity"));
                    vec.add(rs.getString("Product_Category"));
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    
    
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        InventoryMenu InventoryMenuModule = new InventoryMenu();
        InventoryMenuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );

    }//GEN-LAST:event_formWindowClosing

    private void searchBar_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchBar_TextFieldKeyTyped
        DefaultTableModel dtm = (DefaultTableModel) viewProduct_Table.getModel();

        TableRowSorter<DefaultTableModel> searchBar = new TableRowSorter<>(dtm);
        viewProduct_Table.setRowSorter(searchBar);

        String searchText = searchBar_TextField.getText();
        searchBar.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
    }//GEN-LAST:event_searchBar_TextFieldKeyTyped

    private void searchBar_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusGained
        if ( searchBar_TextField.getText().equals("Search"))
        {
             searchBar_TextField.setText("");
             searchBar_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusGained

    private void searchBar_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusLost
        if (searchBar_TextField.getText().equals(""))
        {
            searchBar_TextField.setText("Search");
            searchBar_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusLost

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try {
            tableUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ViewProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_formWindowOpened

   
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewProduct().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel lower_Panel;
    private javax.swing.JTextField searchBar_TextField;
    private javax.swing.JLabel viewProduct_Label;
    private javax.swing.JScrollPane viewProduct_ScrollPane;
    public static javax.swing.JTable viewProduct_Table;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
