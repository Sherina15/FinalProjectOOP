package InventoryAndSchedulingSystem;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.RowFilter;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;


public class ViewAdminAccount extends javax.swing.JFrame {

    public ViewAdminAccount() 
    {
        initComponents();
        
        name_TextField.setEditable(false);
        email_TextField.setEditable(false);
        phoneNumber_TextField.setEditable(false);
        username_TextField.setEditable(false);
        password_Field.setEditable(false);
        
        try 
        {
            tableUpdate();
            Connection();   
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }      
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";    
   
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);   
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        whole_Panel = new javax.swing.JPanel();
        username_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        phoneNumber_Label = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        top_Panel = new javax.swing.JPanel();
        clientShop_Logo = new javax.swing.JLabel();
        adminAccount_Label = new javax.swing.JLabel();
        add_Button = new javax.swing.JButton();
        edit_Button = new javax.swing.JButton();
        delete_Button = new javax.swing.JButton();
        view_Button = new javax.swing.JButton();
        show_Icon = new javax.swing.JLabel();
        hide_Icon = new javax.swing.JLabel();
        viewAdminAccountList_ScrollPane = new javax.swing.JScrollPane();
        viewAdminAccountList_Table = new javax.swing.JTable();
        name_TextField = new javax.swing.JTextField();
        email_TextField = new javax.swing.JTextField();
        name_Label = new javax.swing.JLabel();
        email_Label = new javax.swing.JLabel();
        searchBar_TextField = new javax.swing.JTextField();
        back_Button = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADMIN ACCOUNT");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setText("Username");
        whole_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, -1, -1));

        username_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        username_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 390, 210, 35));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setText("Password");
        whole_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, -1, -1));

        password_Field.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        password_Field.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 460, 210, 35));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        whole_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, -1, -1));

        phoneNumber_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        phoneNumber_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        phoneNumber_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                phoneNumber_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 320, 210, 35));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        adminAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        adminAccount_Label.setForeground(new java.awt.Color(255, 255, 255));
        adminAccount_Label.setText("Admin Account");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminAccount_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 373, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 653, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addContainerGap())
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addComponent(clientShop_Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 2, Short.MAX_VALUE))
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminAccount_Label, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1110, 90));

        add_Button.setBackground(new java.awt.Color(204, 204, 204));
        add_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        add_Button.setText("Add Account ");
        add_Button.setToolTipText("");
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(add_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 580, 120, -1));

        edit_Button.setBackground(new java.awt.Color(204, 204, 204));
        edit_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        edit_Button.setText("Edit Account");
        edit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(edit_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 580, 110, -1));

        delete_Button.setBackground(new java.awt.Color(204, 204, 204));
        delete_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        delete_Button.setText("Delete Account ");
        delete_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(delete_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 580, 140, -1));

        view_Button.setBackground(new java.awt.Color(204, 204, 204));
        view_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        view_Button.setText("View Account ");
        view_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(view_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 580, 120, -1));

        show_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyes.png"))); // NOI18N
        show_Icon.setToolTipText("Show Password");
        show_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                show_IconMousePressed(evt);
            }
        });
        whole_Panel.add(show_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, -1, 30));

        hide_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_hideeye.png"))); // NOI18N
        hide_Icon.setToolTipText("Hide password");
        hide_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide_IconMousePressed(evt);
            }
        });
        whole_Panel.add(hide_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 460, -1, 30));

        viewAdminAccountList_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Name ", "Email", "Phone Number", "Username", "Password"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        viewAdminAccountList_Table.getTableHeader().setReorderingAllowed(false);
        viewAdminAccountList_Table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                viewAdminAccountList_TableMouseClicked(evt);
            }
        });
        viewAdminAccountList_ScrollPane.setViewportView(viewAdminAccountList_Table);
        if (viewAdminAccountList_Table.getColumnModel().getColumnCount() > 0) {
            viewAdminAccountList_Table.getColumnModel().getColumn(0).setResizable(false);
            viewAdminAccountList_Table.getColumnModel().getColumn(1).setResizable(false);
            viewAdminAccountList_Table.getColumnModel().getColumn(2).setResizable(false);
            viewAdminAccountList_Table.getColumnModel().getColumn(3).setResizable(false);
            viewAdminAccountList_Table.getColumnModel().getColumn(4).setResizable(false);
        }

        whole_Panel.add(viewAdminAccountList_ScrollPane, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, 830, 420));

        name_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        name_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(name_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 180, 210, 35));

        email_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        email_TextField.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        whole_Panel.add(email_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 210, 35));

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name_Label.setText("Name");
        whole_Panel.add(name_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 50, -1));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        email_Label.setText("Email");
        whole_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, -1, -1));

        searchBar_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        searchBar_TextField.setForeground(new java.awt.Color(153, 153, 153));
        searchBar_TextField.setText("Search");
        searchBar_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                searchBar_TextFieldFocusLost(evt);
            }
        });
        searchBar_TextField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchBar_TextFieldMouseClicked(evt);
            }
        });
        searchBar_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                searchBar_TextFieldKeyTyped(evt);
            }
        });
        whole_Panel.add(searchBar_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, 200, 30));

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Close");
        back_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(back_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 580, 102, 30));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Admin Personal Information");
        whole_Panel.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 100, -1, 30));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 1110, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    static int selectedRowIndex;
    
    private void tableUpdate() throws SQLException{
        
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("SELECT * FROM registration_database");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c = Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)viewAdminAccountList_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ; a <= c; a++)
                {
                    vec.add(rs.getString("Name"));
                    vec.add(rs.getString("Email"));
                    vec.add(rs.getString("PhoneNumber"));
                    vec.add(rs.getString("Username"));
                    vec.add(rs.getString("Password"));
                }
                dtm.addRow(vec);
            } 
        }
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
        private void viewAccount() 
        {
        
            String acc_name = name_TextField.getText();
            String acc_email = email_TextField.getText();
            String acc_username = username_TextField.getText();
            String acc_password = String.valueOf(password_Field.getPassword());
            String acc_phone_number = phoneNumber_TextField.getText();

            String username = username_TextField.getText();
            String password = password_Field.getText();

            try 
            {
                String query = "SELECT * FROM registration_database WHERE Username = ? AND Password = ?";
                PreparedStatement pst = con.prepareStatement(query);
                pst.setString(1, username);
                pst.setString(2, password);

                ResultSet rs = pst.executeQuery();

                if (rs.next()) 
                {
                    String name = rs.getString("Name");
                    String email = rs.getString("Email");
                    String phoneNumber = rs.getString("PhoneNumber");
                    
                    ViewAccount viewAccountModule = new ViewAccount();
                    
                    viewAccountModule.name_TextField.setText(name);
                    viewAccountModule.email_TextField.setText(email);
                    viewAccountModule.phoneNumber_TextField.setText(phoneNumber);
                    viewAccountModule.username_TextField.setText(username);
                    viewAccountModule.password_Field.setText(password);

                    viewAccountModule.setVisible(true);
                    dispose();
                } 
                else 
                {
                    JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Selection Required", JOptionPane.INFORMATION_MESSAGE);
                }
            } 
            catch (SQLException ex) 
            {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database error: " + ex.getMessage(),"Error", JOptionPane.ERROR_MESSAGE);
            }
        }   
        
    private void clearFields() 
    {
        name_TextField.setText("");
        email_TextField.setText("");
        username_TextField.setText("");
        password_Field.setText("");
        phoneNumber_TextField.setText("");
    }

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        MenuSystem menuSystemModule = new MenuSystem();
        menuSystemModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
       AddAccount addAccountModule = new AddAccount();
       addAccountModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void edit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_ButtonActionPerformed
       EditAccount editAccountModule = new EditAccount();
       editAccountModule.setVisible(true);
       dispose();
    }//GEN-LAST:event_edit_ButtonActionPerformed

    private void view_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view_ButtonActionPerformed
        
        viewAccount();
        
    }//GEN-LAST:event_view_ButtonActionPerformed

    private void hide_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide_IconMousePressed
        show_Icon.setVisible(true);
        hide_Icon.setVisible(false);
        
        password_Field.setEchoChar ('•');
    }//GEN-LAST:event_hide_IconMousePressed

    private void show_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_IconMousePressed
        show_Icon.setVisible(false);
        hide_Icon.setVisible(true);
        
        password_Field.setEchoChar ((char)0); 
    }//GEN-LAST:event_show_IconMousePressed

    private void delete_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_ButtonActionPerformed
        String name = name_TextField.getText(); // Assuming Name is not used for deletion
        String email = email_TextField.getText();
        String username = username_TextField.getText();
        String password = password_Field.getText();
        String phoneNumber = phoneNumber_TextField.getText();

        DefaultTableModel dtm = (DefaultTableModel) viewAdminAccountList_Table.getModel();
        int selectedIndex = viewAdminAccountList_Table.getSelectedRow();

        try 
        {
            if (selectedIndex != -1) 
            {
                int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete " + username + "?", "Delete", JOptionPane.YES_NO_OPTION);

                if (choice == JOptionPane.YES_OPTION) 
                {
                    Class.forName(dbDriver);
                    con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);

                    PreparedStatement deleteStmt = con.prepareStatement("DELETE FROM registration_database WHERE Email = ?");
                    deleteStmt.setString(1, email);

                    int rowsDeleted = deleteStmt.executeUpdate();

                    if (rowsDeleted > 0) 
                    {
                        JOptionPane.showMessageDialog(this, "Record Deleted Successfully", "Delete", JOptionPane.INFORMATION_MESSAGE);
                        
                        tableUpdate(); 
                        clearFields();
                    } 
                    else 
                    {
                        JOptionPane.showMessageDialog(this, "Failed to delete record.", "Error", JOptionPane.ERROR_MESSAGE);
                        clearFields();
                    }
                    
                } 
                else 
                {
                    JOptionPane.showMessageDialog(this, "Deletion Cancelled.", "Cancelled", JOptionPane.INFORMATION_MESSAGE);
                        clearFields() ;
                }
            } 
            else 
            {
                JOptionPane.showMessageDialog(this, "Please select a row to delete.", "Selection Required", JOptionPane.INFORMATION_MESSAGE);
            }
        } 
        catch (ClassNotFoundException | SQLException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_delete_ButtonActionPerformed

    private void viewAdminAccountList_TableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_viewAdminAccountList_TableMouseClicked
       DefaultTableModel dtm = (DefaultTableModel)viewAdminAccountList_Table.getModel();
       int selectedIndex = viewAdminAccountList_Table.getSelectedRow();

       selectedRowIndex = viewAdminAccountList_Table.getSelectedRow();
    
       name_TextField.setText(dtm.getValueAt(selectedIndex, 0).toString());
       email_TextField.setText(dtm.getValueAt(selectedIndex, 1).toString());
       phoneNumber_TextField.setText(dtm.getValueAt(selectedIndex, 2).toString());
       username_TextField.setText(dtm.getValueAt(selectedIndex, 3).toString());
       password_Field.setText(dtm.getValueAt(selectedIndex, 4).toString());
       
    }//GEN-LAST:event_viewAdminAccountList_TableMouseClicked

    private void phoneNumber_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            phoneNumber_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            phoneNumber_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_phoneNumber_TextFieldKeyTyped

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
            
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );

    }//GEN-LAST:event_formWindowClosing

    private void searchBar_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_searchBar_TextFieldKeyTyped
        DefaultTableModel dtm = (DefaultTableModel) viewAdminAccountList_Table.getModel();

        TableRowSorter<DefaultTableModel> searchBar = new TableRowSorter<>(dtm);
        viewAdminAccountList_Table.setRowSorter(searchBar);

        String searchText = searchBar_TextField.getText();
        searchBar.setRowFilter(RowFilter.regexFilter("(?i)" + searchText));
    }//GEN-LAST:event_searchBar_TextFieldKeyTyped

    private void searchBar_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusGained
        if ( searchBar_TextField.getText().equals("Search"))
        {
             searchBar_TextField.setText("");
             searchBar_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusGained

    private void searchBar_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_searchBar_TextFieldFocusLost
        if (searchBar_TextField.getText().equals(""))
        {
            searchBar_TextField.setText("Search");
            searchBar_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_searchBar_TextFieldFocusLost

    private void searchBar_TextFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchBar_TextFieldMouseClicked
        
        clearFields();
        
    }//GEN-LAST:event_searchBar_TextFieldMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        try 
        {
            tableUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(ViewAdminAccount.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_formWindowOpened

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ViewAdminAccount().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_Button;
    private javax.swing.JLabel adminAccount_Label;
    private javax.swing.JButton back_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JButton delete_Button;
    private javax.swing.JButton edit_Button;
    private javax.swing.JLabel email_Label;
    public static javax.swing.JTextField email_TextField;
    private javax.swing.JLabel hide_Icon;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel name_Label;
    public static javax.swing.JTextField name_TextField;
    public static javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    public static javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JTextField searchBar_TextField;
    private javax.swing.JLabel show_Icon;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JLabel username_Label;
    public static javax.swing.JTextField username_TextField;
    private javax.swing.JScrollPane viewAdminAccountList_ScrollPane;
    public static javax.swing.JTable viewAdminAccountList_Table;
    private javax.swing.JButton view_Button;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
