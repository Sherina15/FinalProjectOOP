package InventoryAndSchedulingSystem;

import static InventoryAndSchedulingSystem.ViewAdminAccount.viewAdminAccountList_Table;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
    
public class Registration extends javax.swing.JFrame {
  
    public Registration() 
    {
        initComponents(); 
       
        try 
        {
            Connection();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }     
    }
    
    Connection con;
    Statement st;
     
    private static final String dbName = "detailshop_registration";
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection Successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);   
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPasswordField1 = new javax.swing.JPasswordField();
        left_Panel = new javax.swing.JPanel();
        right_Panel = new javax.swing.JPanel();
        registration_Label = new javax.swing.JLabel();
        greetings_Label = new javax.swing.JLabel();
        email_Icon = new javax.swing.JLabel();
        username_Label = new javax.swing.JLabel();
        username_Icon = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        key_Icon = new javax.swing.JLabel();
        password_Field = new javax.swing.JPasswordField();
        show_Icon = new javax.swing.JLabel();
        hide_Icon = new javax.swing.JLabel();
        name_Label = new javax.swing.JLabel();
        phoneNumber_Label = new javax.swing.JLabel();
        phone_Icon = new javax.swing.JLabel();
        phoneNumber_TextField = new javax.swing.JTextField();
        register_Button = new javax.swing.JButton();
        signIn_Label_Button = new javax.swing.JLabel();
        signIn_Labels_Buttons = new javax.swing.JLabel();
        name_TextField = new javax.swing.JTextField();
        email_TextField = new javax.swing.JTextField();
        email_Label = new javax.swing.JLabel();
        namePattern_Label = new javax.swing.JLabel();
        profile_Icon = new javax.swing.JLabel();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();

        jPasswordField1.setText("jPasswordField1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("REGISTRATION");
        setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        left_Panel.setBackground(new java.awt.Color(0, 0, 0));
        left_Panel.setPreferredSize(new java.awt.Dimension(800, 600));

        right_Panel.setBackground(new java.awt.Color(255, 255, 255));
        right_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        registration_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        registration_Label.setText("REGISTRATION");
        right_Panel.add(registration_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 10, 360, -1));

        greetings_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        greetings_Label.setForeground(new java.awt.Color(51, 51, 51));
        greetings_Label.setText("LET'S GET STARTED ");
        right_Panel.add(greetings_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, -1, -1));

        email_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_envelope.png"))); // NOI18N
        right_Panel.add(email_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 250, -1, 36));

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        username_Label.setText("Username");
        right_Panel.add(username_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 360, -1, -1));

        username_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_username.png"))); // NOI18N
        right_Panel.add(username_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 390, -1, 36));

        username_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        username_TextField.setForeground(new java.awt.Color(153, 153, 153));
        username_TextField.setText("Enter Username");
        username_TextField.setToolTipText("");
        username_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusLost(evt);
            }
        });
        right_Panel.add(username_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, 260, 36));

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        password_Label.setText("Password");
        right_Panel.add(password_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 430, -1, -1));

        key_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_key.png"))); // NOI18N
        right_Panel.add(key_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 460, -1, 36));

        password_Field.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        password_Field.setForeground(new java.awt.Color(153, 153, 153));
        password_Field.setText("Enter Password");
        password_Field.setEchoChar('\u0000');
        password_Field.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                password_FieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                password_FieldFocusLost(evt);
            }
        });
        right_Panel.add(password_Field, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 460, 260, 36));

        show_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_eyes.png"))); // NOI18N
        show_Icon.setToolTipText("Show password");
        show_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                show_IconMousePressed(evt);
            }
        });
        right_Panel.add(show_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 470, -1, -1));

        hide_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_hideeye.png"))); // NOI18N
        hide_Icon.setToolTipText("Hide password");
        hide_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                hide_IconMousePressed(evt);
            }
        });
        right_Panel.add(hide_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 470, -1, -1));

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        name_Label.setText("Name");
        right_Panel.add(name_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        phoneNumber_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        phoneNumber_Label.setText("Phone Number");
        right_Panel.add(phoneNumber_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 290, -1, -1));

        phone_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_phone.png"))); // NOI18N
        right_Panel.add(phone_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 320, -1, 36));

        phoneNumber_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        phoneNumber_TextField.setForeground(new java.awt.Color(153, 153, 153));
        phoneNumber_TextField.setText("Enter Phone Number");
        phoneNumber_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                phoneNumber_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                phoneNumber_TextFieldFocusLost(evt);
            }
        });
        phoneNumber_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                phoneNumber_TextFieldKeyTyped(evt);
            }
        });
        right_Panel.add(phoneNumber_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 320, 260, 36));

        register_Button.setBackground(new java.awt.Color(0, 0, 0));
        register_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        register_Button.setForeground(new java.awt.Color(255, 255, 255));
        register_Button.setText("REGISTER");
        register_Button.setToolTipText("Click to register an account");
        register_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        register_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                register_ButtonActionPerformed(evt);
            }
        });
        right_Panel.add(register_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 520, 322, 40));

        signIn_Label_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        signIn_Label_Button.setText("Already have an account? ");
        signIn_Label_Button.setToolTipText("Click to go to the login page");
        signIn_Label_Button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signIn_Label_ButtonMouseClicked(evt);
            }
        });
        right_Panel.add(signIn_Label_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 570, 180, 30));

        signIn_Labels_Buttons.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        signIn_Labels_Buttons.setForeground(new java.awt.Color(102, 0, 0));
        signIn_Labels_Buttons.setText("Sign In");
        signIn_Labels_Buttons.setToolTipText("Click to go to the login page");
        signIn_Labels_Buttons.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                signIn_Labels_ButtonsMouseClicked(evt);
            }
        });
        right_Panel.add(signIn_Labels_Buttons, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 570, 90, 30));

        name_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        name_TextField.setForeground(new java.awt.Color(153, 153, 153));
        name_TextField.setText("Enter Name");
        name_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                name_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                name_TextFieldFocusLost(evt);
            }
        });
        right_Panel.add(name_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 160, 260, 36));

        email_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        email_TextField.setForeground(new java.awt.Color(153, 153, 153));
        email_TextField.setText("Enter Email");
        email_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                email_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                email_TextFieldFocusLost(evt);
            }
        });
        right_Panel.add(email_TextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 250, 260, 36));

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        email_Label.setText("Email");
        right_Panel.add(email_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, -1));

        namePattern_Label.setFont(new java.awt.Font("Segoe UI", 3, 12)); // NOI18N
        namePattern_Label.setForeground(new java.awt.Color(51, 51, 51));
        namePattern_Label.setText("( Surname, Name )");
        right_Panel.add(namePattern_Label, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 200, -1, -1));

        profile_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_user.png"))); // NOI18N
        right_Panel.add(profile_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 160, 30, 40));

        clientShop_Logo.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/client_logo.png"))); // NOI18N

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        clientShop_Name.setForeground(new java.awt.Color(255, 255, 255));
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");

        javax.swing.GroupLayout left_PanelLayout = new javax.swing.GroupLayout(left_Panel);
        left_Panel.setLayout(left_PanelLayout);
        left_PanelLayout.setHorizontalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addContainerGap(60, Short.MAX_VALUE)
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(clientShop_Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clientShop_Name, javax.swing.GroupLayout.PREFERRED_SIZE, 304, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(56, 56, 56)
                .addComponent(right_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        left_PanelLayout.setVerticalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGap(139, 139, 139)
                .addComponent(clientShop_Logo)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(clientShop_Name)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addComponent(right_Panel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 650, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(left_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(left_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    public void clearFields()
    {
        name_TextField.setText("Enter Name");
        email_TextField.setText("Enter Email");
        username_TextField.setText("Enter Username");
        password_Field.setText("Enter Password");
        phoneNumber_TextField.setText("Enter Phone Number");     
    }
    
    private void show_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_IconMousePressed
        show_Icon.setVisible(false);
        hide_Icon.setVisible(true);
        
        password_Field.setEchoChar ((char)0);        
    }//GEN-LAST:event_show_IconMousePressed

    private void hide_IconMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_hide_IconMousePressed
        show_Icon.setVisible(true);
        hide_Icon.setVisible(false);
        
        password_Field.setEchoChar ('•');
    }//GEN-LAST:event_hide_IconMousePressed

    private void email_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_email_TextFieldFocusGained
        if ( email_TextField.getText().equals("Enter Email"))
        {
             email_TextField.setText("");
             email_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_email_TextFieldFocusGained

    private void email_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_email_TextFieldFocusLost
        if (email_TextField.getText().equals(""))
        {
            email_TextField.setText("Enter Email");
            email_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_email_TextFieldFocusLost

    private void username_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusGained
        if (username_TextField.getText().equals("Enter Username"))
        {
            username_TextField.setText("");
            username_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_username_TextFieldFocusGained

    private void username_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusLost
        if (username_TextField.getText().equals(""))
        {
            username_TextField.setText("Enter Username");
            username_TextField.setForeground(new java.awt.Color(153,153,153));
        }     
    }//GEN-LAST:event_username_TextFieldFocusLost

    private void password_FieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_FieldFocusGained
        if (String.valueOf(password_Field.getPassword()).equals("Enter Password"))
        {
           password_Field.setText("");
           password_Field.setForeground(Color.BLACK);
           password_Field.setEchoChar('•');
        }
    }//GEN-LAST:event_password_FieldFocusGained

    private void password_FieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_FieldFocusLost
        if (password_Field.getPassword().length<1)
        {
            password_Field.setEchoChar('\u0000');
            password_Field.setText("Enter Password");
            password_Field.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_password_FieldFocusLost

    private void phoneNumber_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldFocusGained
        if (phoneNumber_TextField.getText().equals("Enter Phone Number"))
        {
            phoneNumber_TextField.setText("");
            phoneNumber_TextField.setForeground(Color.BLACK);
        }       
    }//GEN-LAST:event_phoneNumber_TextFieldFocusGained

    private void phoneNumber_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldFocusLost
        if (phoneNumber_TextField.getText().equals(""))
        {
            phoneNumber_TextField.setText("Enter Phone Number");
            phoneNumber_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_phoneNumber_TextFieldFocusLost

    private void signIn_Label_ButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signIn_Label_ButtonMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_signIn_Label_ButtonMouseClicked

    private void signIn_Labels_ButtonsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_signIn_Labels_ButtonsMouseClicked
        Login loginModule = new Login();
        loginModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_signIn_Labels_ButtonsMouseClicked

    private void register_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_register_ButtonActionPerformed
        ViewAdminAccount  viewAdminAccountModule = new ViewAdminAccount();
        
        String acc_Name = name_TextField.getText();  
        String acc_Email = email_TextField.getText();
        String acc_Phone_Number = phoneNumber_TextField.getText();  
        String acc_Username = username_TextField.getText();
        String acc_Password = String.valueOf(password_Field.getPassword());
        
        String regEx_Name = "^[A-Za-z\\s'-]+, [A-Za-z\\s'-]+$";
        String regEx_Email = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        String regEx_PhoneNumber = "^09\\d{9}$";

        Pattern pattern_Name = Pattern.compile(regEx_Name);
        Pattern pattern_Email = Pattern.compile(regEx_Email);
        Pattern pattern_PhoneNumber = Pattern.compile(regEx_PhoneNumber);
    
        Matcher matcher_Name = pattern_Name.matcher(acc_Name);
        Matcher matcher_Email = pattern_Email.matcher(acc_Email);
        Matcher matcher_PhoneNumber = pattern_PhoneNumber.matcher(acc_Phone_Number);
        
        String username;
        int account = 0;
        
        for (int i = 0; i < ViewAdminAccount.viewAdminAccountList_Table.getRowCount(); i++)
        {
            username = viewAdminAccountList_Table.getValueAt(i, 3).toString();
            
            if (acc_Username.equalsIgnoreCase(viewAdminAccountList_Table.getValueAt(i, 3).toString()))
            {
                account++;  
            }
        }
                if (name_TextField.getText().equals("") || email_TextField.getText().equals("") || phoneNumber_TextField.getText().equals("") || username_TextField.getText().equals("") || password_Field.getText().equals("")) 
                {
                    JOptionPane.showMessageDialog(null, "Kindly fill out the field.", "Error: Missing Field", JOptionPane.ERROR_MESSAGE);
                    clearFields();   
                }
                else if (name_TextField.getText().equals("Enter Name") || email_TextField.getText().equals("Enter Email") || phoneNumber_TextField.getText().equals("Enter Phone Number") || username_TextField.getText().equals("Enter Username")|| password_Field.getText().equals("Enter Password")) 
                {
                    JOptionPane.showMessageDialog(null, "Invalid Input.", "Error: Invalid Input Detected", JOptionPane.ERROR_MESSAGE);
                    clearFields();
                }
                else if (!matcher_Name.matches())
                {
                     JOptionPane.showMessageDialog(null, "Name is formatted incorrectly.", "Error: Invalid Name Format", JOptionPane.ERROR_MESSAGE);
                     name_TextField.setText("Enter Name");
                }
                else if (!matcher_Email.matches())
                {
                    JOptionPane.showMessageDialog(null, "Email is formatted incorrectly.", "Error: Invalid Email Format",JOptionPane.ERROR_MESSAGE);
                    email_TextField.setText("Enter Email");
                }
                else if (!matcher_PhoneNumber.matches())
                {
                    JOptionPane.showMessageDialog(null, "Contact Number is formatted incorrectly.", "Error: Invalid Contact Number Format", JOptionPane.ERROR_MESSAGE);
                    phoneNumber_TextField.setText("Enter Phone Number");
                }
                else if (account != 0)
                {
                    JOptionPane.showMessageDialog(null, "The username " + acc_Username + "  is already exists.", "Warning: Username Already Taken", JOptionPane.WARNING_MESSAGE);
                    username_TextField.setText("Enter Username");
                }
                else 
                {
                    int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to register this account?","Register",JOptionPane.YES_NO_OPTION);

                    if (choice == JOptionPane.YES_OPTION)
                    {
                        try 
                        {
                            String queryRegister = "INSERT INTO registration_database (Name,Email,PhoneNumber,Username,Password) VALUES ('"+acc_Name+"', '"+acc_Email+"', '"+acc_Phone_Number+"', '"+acc_Username+"', '"+acc_Password+"')";
                            st.execute(queryRegister );
                            JOptionPane.showMessageDialog(new JFrame(), "Register Successfully.", "Registration Success",JOptionPane.INFORMATION_MESSAGE);

                            Login loginFrame = new Login();
                            loginFrame.setVisible(true);
                            dispose();
                        }
                        catch (SQLException ex) 
                        {
                            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, "Error adding profile", ex);
                            JOptionPane.showMessageDialog(null, "An error occurred while adding the profile. Please try again later.", "Error", JOptionPane.ERROR_MESSAGE);
                        } 
                    }
                    else
                    {
                    JOptionPane.showMessageDialog(new JFrame(), "Failed to Register Account.","Registration Failed",JOptionPane.ERROR_MESSAGE);
                    }     
                }       
    }//GEN-LAST:event_register_ButtonActionPerformed

    private void phoneNumber_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_phoneNumber_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            phoneNumber_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            phoneNumber_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_phoneNumber_TextFieldKeyTyped

    private void name_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_name_TextFieldFocusGained
        if (name_TextField.getText().equals("Enter Name"))
        {
            name_TextField.setText("");
            name_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_name_TextFieldFocusGained

    private void name_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_name_TextFieldFocusLost
        if (name_TextField.getText().equals(""))
        {
            name_TextField.setText("Enter Name");
            name_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_name_TextFieldFocusLost

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
               
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );

    }//GEN-LAST:event_formWindowClosing
   
  
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Registration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JLabel email_Icon;
    private javax.swing.JLabel email_Label;
    private javax.swing.JTextField email_TextField;
    private javax.swing.JLabel greetings_Label;
    private javax.swing.JLabel hide_Icon;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JLabel key_Icon;
    private javax.swing.JPanel left_Panel;
    private javax.swing.JLabel namePattern_Label;
    private javax.swing.JLabel name_Label;
    private javax.swing.JTextField name_TextField;
    private javax.swing.JPasswordField password_Field;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phoneNumber_Label;
    private javax.swing.JTextField phoneNumber_TextField;
    private javax.swing.JLabel phone_Icon;
    private javax.swing.JLabel profile_Icon;
    private javax.swing.JButton register_Button;
    private javax.swing.JLabel registration_Label;
    private javax.swing.JPanel right_Panel;
    private javax.swing.JLabel show_Icon;
    private javax.swing.JLabel signIn_Label_Button;
    private javax.swing.JLabel signIn_Labels_Buttons;
    private javax.swing.JLabel username_Icon;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    // End of variables declaration//GEN-END:variables
}
