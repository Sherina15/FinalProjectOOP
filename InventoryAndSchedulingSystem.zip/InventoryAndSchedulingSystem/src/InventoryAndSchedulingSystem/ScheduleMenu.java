package InventoryAndSchedulingSystem;

import java.util.Base64;
import javax.swing.JOptionPane;

public class ScheduleMenu extends javax.swing.JFrame {
    
    public ScheduleMenu() 
    {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        left_Panel = new javax.swing.JPanel();
        exit_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();
        clientShop_Name = new javax.swing.JLabel();
        home_Button = new javax.swing.JButton();
        list_Button = new javax.swing.JButton();
        inventory_Button = new javax.swing.JButton();
        productList_Button = new javax.swing.JButton();
        top_Panel = new javax.swing.JPanel();
        schedule_Label = new javax.swing.JLabel();
        logoutHome_Icon = new javax.swing.JLabel();
        viewSchedule_Button = new javax.swing.JButton();
        addSchedule_Button = new javax.swing.JButton();
        editSchedule_Button = new javax.swing.JButton();
        appointmentReport_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SCHEDULE MENU");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(255, 255, 255));
        whole_Panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        whole_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        left_Panel.setBackground(new java.awt.Color(255, 255, 255));
        left_Panel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));

        exit_Button.setBackground(new java.awt.Color(204, 204, 204));
        exit_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        exit_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_exit.png"))); // NOI18N
        exit_Button.setText("Exit");
        exit_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        exit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit_ButtonActionPerformed(evt);
            }
        });

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/2x2_client_logo.png"))); // NOI18N

        clientShop_Name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        clientShop_Name.setText("DeTails Pet Essentials and Lodging");

        home_Button.setBackground(new java.awt.Color(204, 204, 204));
        home_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        home_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_home.png"))); // NOI18N
        home_Button.setText("Home");
        home_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        home_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                home_ButtonActionPerformed(evt);
            }
        });

        list_Button.setBackground(new java.awt.Color(204, 204, 204));
        list_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        list_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_accountlist.png"))); // NOI18N
        list_Button.setText("Admin Account");
        list_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        list_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                list_ButtonActionPerformed(evt);
            }
        });

        inventory_Button.setBackground(new java.awt.Color(204, 204, 204));
        inventory_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        inventory_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_inventory.png"))); // NOI18N
        inventory_Button.setText("Inventory ");
        inventory_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        inventory_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                inventory_ButtonActionPerformed(evt);
            }
        });

        productList_Button.setBackground(new java.awt.Color(204, 204, 204));
        productList_Button.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        productList_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_list.png"))); // NOI18N
        productList_Button.setText("Product List");
        productList_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        productList_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                productList_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout left_PanelLayout = new javax.swing.GroupLayout(left_Panel);
        left_Panel.setLayout(left_PanelLayout);
        left_PanelLayout.setHorizontalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(home_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(list_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(inventory_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(productList_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, left_PanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(clientShop_Name))
                    .addComponent(exit_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(clientShop_Logo)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        left_PanelLayout.setVerticalGroup(
            left_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(left_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(clientShop_Logo)
                .addGap(18, 18, 18)
                .addComponent(clientShop_Name)
                .addGap(29, 29, 29)
                .addComponent(home_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(list_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(inventory_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(productList_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(exit_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(96, Short.MAX_VALUE))
        );

        whole_Panel.add(left_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 610));

        top_Panel.setBackground(new java.awt.Color(0, 0, 0));

        schedule_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        schedule_Label.setForeground(new java.awt.Color(255, 255, 255));
        schedule_Label.setText("SCHEDULE ");

        javax.swing.GroupLayout top_PanelLayout = new javax.swing.GroupLayout(top_Panel);
        top_Panel.setLayout(top_PanelLayout);
        top_PanelLayout.setHorizontalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(top_PanelLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(schedule_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        top_PanelLayout.setVerticalGroup(
            top_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, top_PanelLayout.createSequentialGroup()
                .addContainerGap(30, Short.MAX_VALUE)
                .addComponent(schedule_Label)
                .addContainerGap())
        );

        whole_Panel.add(top_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 0, 600, 100));

        logoutHome_Icon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_logout.png"))); // NOI18N
        logoutHome_Icon.setToolTipText("Logout account");
        logoutHome_Icon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutHome_IconMouseClicked(evt);
            }
        });
        whole_Panel.add(logoutHome_Icon, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 550, 50, 60));

        viewSchedule_Button.setBackground(new java.awt.Color(204, 204, 204));
        viewSchedule_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        viewSchedule_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_view.png"))); // NOI18N
        viewSchedule_Button.setText("View Schedule");
        viewSchedule_Button.setToolTipText("Click to view schedule");
        viewSchedule_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        viewSchedule_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewSchedule_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(viewSchedule_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 120, 540, 80));

        addSchedule_Button.setBackground(new java.awt.Color(204, 204, 204));
        addSchedule_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        addSchedule_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_add.png"))); // NOI18N
        addSchedule_Button.setText("Add Schedule");
        addSchedule_Button.setToolTipText("Click to add schedule");
        addSchedule_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        addSchedule_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addSchedule_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(addSchedule_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 210, 540, 80));

        editSchedule_Button.setBackground(new java.awt.Color(204, 204, 204));
        editSchedule_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        editSchedule_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_refresh.png"))); // NOI18N
        editSchedule_Button.setText("Edit Schedule");
        editSchedule_Button.setToolTipText("Click to edit schedule");
        editSchedule_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        editSchedule_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editSchedule_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(editSchedule_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 300, 540, 80));

        appointmentReport_Button.setBackground(new java.awt.Color(204, 204, 204));
        appointmentReport_Button.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        appointmentReport_Button.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/icon_report.png"))); // NOI18N
        appointmentReport_Button.setText("Appointment Report");
        appointmentReport_Button.setToolTipText("Click to see appointment report");
        appointmentReport_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        appointmentReport_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                appointmentReport_ButtonActionPerformed(evt);
            }
        });
        whole_Panel.add(appointmentReport_Button, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 390, 540, 80));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
    
    String storedPasswordHash = hashPassword("0000");
    
    private static String hashPassword(String password) 
    {
        return Base64.getEncoder().encodeToString(password.getBytes());
    }
    
    private static boolean isPasswordCorrect(String enteredPassword, String storedPasswordHash) 
    { 
        String enteredPasswordHash = hashPassword(enteredPassword);
        return storedPasswordHash.equals(enteredPasswordHash);
    }
    
    private void exit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exit_ButtonActionPerformed
        int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to exit application?","Exit",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
       
        if (choice == JOptionPane.NO_OPTION )
        {
           
        }
        else
        {
            JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );
            System.exit(0);
        }
    }//GEN-LAST:event_exit_ButtonActionPerformed

    private void home_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_home_ButtonActionPerformed
        MenuSystem menuSystemModule = new MenuSystem();
        menuSystemModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_home_ButtonActionPerformed

    private void list_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_list_ButtonActionPerformed
        String enter = JOptionPane.showInputDialog(null, "Enter Password", "Verification", JOptionPane.PLAIN_MESSAGE);

        if (enter == null) 
        {
            JOptionPane.showMessageDialog(null, "Operation canceled by user");
        }
        
        else if (enter.isEmpty()) 
        {
            JOptionPane.showMessageDialog(null, "Please input password");   
        } 
        else 
        {
            if (isPasswordCorrect(enter, storedPasswordHash)) 
            {
                JOptionPane.showMessageDialog(null, "Password correct!");
                ViewAdminAccount viewAdminAccountModule = new ViewAdminAccount();
                viewAdminAccountModule.setVisible(true);
                dispose();
            } 
            else 
            {
                JOptionPane.showMessageDialog(null, "Incorrect Password");
            }
        }
    }//GEN-LAST:event_list_ButtonActionPerformed

    private void inventory_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inventory_ButtonActionPerformed
        InventoryMenu InventoryMenuModule = new InventoryMenu();
        InventoryMenuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_inventory_ButtonActionPerformed

    private void productList_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_productList_ButtonActionPerformed
        ProductList producListModule = new ProductList();
        producListModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_productList_ButtonActionPerformed

    private void logoutHome_IconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutHome_IconMouseClicked
       int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?","Logout",JOptionPane.YES_NO_OPTION,JOptionPane.WARNING_MESSAGE);
       
       if (choice == JOptionPane.NO_OPTION)
       {
           
       }
       else
       {
            JOptionPane.showMessageDialog(null, "The account has been successfully logged out.","Logout Successful",JOptionPane.INFORMATION_MESSAGE );
            Login loginModule = new Login();
            loginModule.setVisible(true);
            dispose();
       }
        
    }//GEN-LAST:event_logoutHome_IconMouseClicked

    private void viewSchedule_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewSchedule_ButtonActionPerformed
        ViewSchedule viewScheduleModule = new ViewSchedule();
        viewScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_viewSchedule_ButtonActionPerformed

    private void addSchedule_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addSchedule_ButtonActionPerformed
        AddSchedule addScheduleModule = new AddSchedule();
        addScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_addSchedule_ButtonActionPerformed

    private void editSchedule_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editSchedule_ButtonActionPerformed
        EditSchedule editScheduleModule = new EditSchedule();
        editScheduleModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_editSchedule_ButtonActionPerformed

    private void appointmentReport_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_appointmentReport_ButtonActionPerformed
        AppointmentReport appointmentReportModule = new  AppointmentReport();
        appointmentReportModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_appointmentReport_ButtonActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        
        JOptionPane.showMessageDialog(null, "The application will be closed","Exit Application",JOptionPane.INFORMATION_MESSAGE );

    }//GEN-LAST:event_formWindowClosing

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ScheduleMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ScheduleMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ScheduleMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ScheduleMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ScheduleMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addSchedule_Button;
    private javax.swing.JButton appointmentReport_Button;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JLabel clientShop_Name;
    private javax.swing.JButton editSchedule_Button;
    private javax.swing.JButton exit_Button;
    private javax.swing.JButton home_Button;
    private javax.swing.JButton inventory_Button;
    private javax.swing.JPanel left_Panel;
    private javax.swing.JButton list_Button;
    private javax.swing.JLabel logoutHome_Icon;
    private javax.swing.JButton productList_Button;
    private javax.swing.JLabel schedule_Label;
    private javax.swing.JPanel top_Panel;
    private javax.swing.JButton viewSchedule_Button;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
