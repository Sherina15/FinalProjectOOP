package InventoryAndSchedulingSystem;

import static InventoryAndSchedulingSystem.ViewProduct.viewProduct_Table;
import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AddProduct extends javax.swing.JFrame {

    private int product = 0;
    private int totalQuantity = 0;
    DecimalFormat decFormat=new DecimalFormat("0.00");

    public AddProduct() 
    {
        initComponents();
        
        setLocationRelativeTo(null);
        
        try 
        {
            Connection();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(AddProduct.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "detailshop_registration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/" + dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        whole_Panel = new javax.swing.JPanel();
        back_Button = new javax.swing.JButton();
        addProduct_Label = new javax.swing.JLabel();
        lower_Panel = new javax.swing.JPanel();
        productName_Label = new javax.swing.JLabel();
        productName_TextField = new javax.swing.JTextField();
        price_Label = new javax.swing.JLabel();
        price_TextField = new javax.swing.JTextField();
        quantity_Label = new javax.swing.JLabel();
        quantity_Spinner = new javax.swing.JSpinner();
        category_Label = new javax.swing.JLabel();
        category_ComboBox = new javax.swing.JComboBox<>();
        add_Button = new javax.swing.JButton();
        clientShop_Logo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADD PRODUCT");
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        whole_Panel.setBackground(new java.awt.Color(0, 0, 0));

        back_Button.setBackground(new java.awt.Color(204, 204, 204));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        addProduct_Label.setBackground(new java.awt.Color(0, 0, 0));
        addProduct_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        addProduct_Label.setForeground(new java.awt.Color(255, 255, 255));
        addProduct_Label.setText("ADD PRODUCT");

        lower_Panel.setBackground(new java.awt.Color(255, 255, 255));
        lower_Panel.setForeground(new java.awt.Color(255, 255, 255));

        productName_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        productName_Label.setText("Product Name");

        productName_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        productName_TextField.setForeground(new java.awt.Color(153, 153, 153));
        productName_TextField.setText("Enter Product Name");
        productName_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                productName_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                productName_TextFieldFocusLost(evt);
            }
        });

        price_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        price_Label.setText("Price");

        price_TextField.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        price_TextField.setForeground(new java.awt.Color(153, 153, 153));
        price_TextField.setText("Enter Price");
        price_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                price_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                price_TextFieldFocusLost(evt);
            }
        });
        price_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                price_TextFieldKeyTyped(evt);
            }
        });

        quantity_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        quantity_Label.setText("Quantity");

        quantity_Spinner.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        quantity_Spinner.setModel(new javax.swing.SpinnerNumberModel(0, 0, 1000000000, 1));
        quantity_Spinner.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                quantity_SpinnerKeyTyped(evt);
            }
        });

        category_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        category_Label.setText("Category");

        category_ComboBox.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        category_ComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "  ", "Brushes and Combs", "Shampoos and Conditioners", "Grooming Tools", "Trimming Supplies", "Electric Tools" }));

        add_Button.setBackground(new java.awt.Color(204, 204, 204));
        add_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        add_Button.setText("Add");
        add_Button.setToolTipText("Add Product");
        add_Button.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout lower_PanelLayout = new javax.swing.GroupLayout(lower_Panel);
        lower_Panel.setLayout(lower_PanelLayout);
        lower_PanelLayout.setHorizontalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addGroup(lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(add_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(productName_Label)
                        .addComponent(productName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(price_Label)
                        .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(quantity_Label)
                        .addComponent(quantity_Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(category_Label)
                        .addComponent(category_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(109, Short.MAX_VALUE))
        );
        lower_PanelLayout.setVerticalGroup(
            lower_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(lower_PanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(productName_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(productName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(price_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(price_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(quantity_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(quantity_Spinner, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(category_Label)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(category_ComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(add_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 52, Short.MAX_VALUE))
        );

        clientShop_Logo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/1x1_logo.png"))); // NOI18N

        javax.swing.GroupLayout whole_PanelLayout = new javax.swing.GroupLayout(whole_Panel);
        whole_Panel.setLayout(whole_PanelLayout);
        whole_PanelLayout.setHorizontalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addComponent(lower_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(back_Button)
                    .addComponent(addProduct_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(clientShop_Logo)
                .addGap(16, 16, 16))
        );
        whole_PanelLayout.setVerticalGroup(
            whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(whole_PanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(whole_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(whole_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button)
                        .addGap(18, 18, 18)
                        .addComponent(addProduct_Label))
                    .addComponent(clientShop_Logo, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(5, 5, 5)
                .addComponent(lower_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 450, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(whole_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void clearFields()
    {
        productName_TextField.setText("Enter Product Name");
        price_TextField.setText("Enter Price");
        quantity_Spinner.setValue(0);
        category_ComboBox.setSelectedItem("  "); 
    }
    
    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        InventoryMenu InventoryMenuModule = new InventoryMenu();
        InventoryMenuModule.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
        ViewProduct viewProductModule = new ViewProduct ();
       
        String Product_Name = productName_TextField.getText();
        String Product_Price = price_TextField.getText();
        int Product_Quantity = (int) quantity_Spinner.getValue();
        String Product_Category = (String) category_ComboBox.getSelectedItem();
        
        String regEx_Product = "^[a-zA-Z0-9\\s\\-_]{1,50}$";

        Pattern pattern_Product = Pattern.compile(regEx_Product);

        Matcher matcher_Product = pattern_Product.matcher(Product_Name);
        
        int name = 0;

        for (int i = 0; i < ViewProduct.viewProduct_Table.getRowCount(); i++)
        {
            
            if (Product_Name.equalsIgnoreCase(viewProduct_Table.getValueAt(i, 0).toString()))
            {
                name++;  
            }
        }
                if (productName_TextField.getText().equals("") || price_TextField.getText().equals("") || quantity_Spinner.getValue().equals(0)|| category_ComboBox.getSelectedItem().equals("  ")) 
                {
                    JOptionPane.showMessageDialog(null, "Kindly fill out the field.", "Error: Missing Field", JOptionPane.ERROR_MESSAGE);
                    clearFields();   
                }
                else if (productName_TextField.getText().equals("Enter Product Name") || price_TextField.getText().equals("Enter Price") || quantity_Spinner.getValue().equals(0)|| category_ComboBox.getSelectedItem().equals("  ")) 
                {
                    JOptionPane.showMessageDialog(null, "Invalid Input.", "Error: Missing Field", JOptionPane.ERROR_MESSAGE);
                    clearFields();   
                }
                else if (!matcher_Product.matches())
                {
                     JOptionPane.showMessageDialog(null, "Product name is formatted incorrectly.", "Error: Invalid Product Name Format", JOptionPane.ERROR_MESSAGE);
                     productName_TextField.setText("");
                }
                else if (name != 0)
                {
                    JOptionPane.showMessageDialog(null, "The Product " + Product_Name + "  is already exists.", "Warning: Product Already Exists", JOptionPane.WARNING_MESSAGE);
                    productName_TextField.setText("Enter Product Name");
                }
                else
                {
                    
                   int choice = JOptionPane.showConfirmDialog (null,"Are you sure you want to add " + productName_TextField.getText() + "?" , "Add Record ",JOptionPane.YES_NO_OPTION); 
                   
                   if (choice == JOptionPane.YES_OPTION)
                   {
                        double product_Amount = Double.parseDouble(Product_Price);
                        DecimalFormat formatter = new DecimalFormat("#,###.00");
        
                        String fproduct_Amount= (formatter.format(product_Amount));
                        
                       try 
                       {
                        String queryRegister = "INSERT INTO inventory_database (Product_Name,Product_Price,Product_Quantity,Product_Category) VALUES ('"+Product_Name+"', '"+fproduct_Amount+"', '"+Product_Quantity+"','"+Product_Category+"')";
                        pst = con.prepareStatement(queryRegister);

                            int rowsAffected = pst.executeUpdate();

                                if (rowsAffected > 0) 
                                {
                                    JOptionPane.showMessageDialog(null, "Product added successfully.","Successfully Added",JOptionPane.INFORMATION_MESSAGE); 
                                    clearFields();
                                    viewProductModule.setVisible(true);
                                    dispose();
                                }
                                else
                                {
                                    JOptionPane.showMessageDialog(null, "Failed to add product.");
                                    clearFields();
                                }
                       }
                       catch(Exception e)
                       {
                            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, "Error updating profile", e);
                            JOptionPane.showMessageDialog(null, "An error occurred while updating the profile. Please try again later.","Error",JOptionPane.ERROR_MESSAGE);  
                            clearFields();
                       }
                    }
                    else if (choice == JOptionPane.NO_OPTION)
                    {
                        JOptionPane.showMessageDialog(null, "Adding products was unsuccessful.","Unsuccessful",JOptionPane.ERROR_MESSAGE); 
                        clearFields();
                    }
                }    
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void quantity_SpinnerKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_quantity_SpinnerKeyTyped
        char c = evt.getKeyChar();
        
        if (!Character.isDigit(c))
        {
            evt.consume();
        }
    }//GEN-LAST:event_quantity_SpinnerKeyTyped

    private void productName_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_productName_TextFieldFocusGained
       if (productName_TextField.getText().equals("Enter Product Name"))
        {
            productName_TextField.setText("");
            productName_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_productName_TextFieldFocusGained

    private void productName_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_productName_TextFieldFocusLost
        if (productName_TextField.getText().equals(""))
        {
            productName_TextField.setText("Enter Product Name");
            productName_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_productName_TextFieldFocusLost

    private void price_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_price_TextFieldFocusGained
        if (price_TextField.getText().equals("Enter Price"))
        {
            price_TextField.setText("");
            price_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_price_TextFieldFocusGained

    private void price_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_price_TextFieldFocusLost
        if (price_TextField.getText().equals(""))
        {
            price_TextField.setText("Enter Price");
            price_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_price_TextFieldFocusLost

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        
        JOptionPane.showMessageDialog(null, "The application will be closed.","Exit Application",JOptionPane.INFORMATION_MESSAGE );
        
    }//GEN-LAST:event_formWindowClosing

    private void price_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_price_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            price_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "You can only input numbers.", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            price_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_price_TextFieldKeyTyped


    public static void main(String args[]) {
  
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AddProduct().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel addProduct_Label;
    private javax.swing.JButton add_Button;
    private javax.swing.JButton back_Button;
    private javax.swing.JComboBox<String> category_ComboBox;
    private javax.swing.JLabel category_Label;
    private javax.swing.JLabel clientShop_Logo;
    private javax.swing.JPanel lower_Panel;
    private javax.swing.JLabel price_Label;
    private javax.swing.JTextField price_TextField;
    private javax.swing.JLabel productName_Label;
    private javax.swing.JTextField productName_TextField;
    private javax.swing.JLabel quantity_Label;
    private javax.swing.JSpinner quantity_Spinner;
    private javax.swing.JPanel whole_Panel;
    // End of variables declaration//GEN-END:variables
}
